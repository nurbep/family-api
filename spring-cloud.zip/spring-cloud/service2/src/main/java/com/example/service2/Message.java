package com.example.service2;

public class Message {
	private String msg;

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public Message(String msg) {
		super();
		this.msg = msg;
	}

}
